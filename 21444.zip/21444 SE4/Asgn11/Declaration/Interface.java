package Declaration;

public interface Interface {

	void insert(int x);
	void delete(int x);
	void display();
	int cnt_size();
	int isempty();
}
