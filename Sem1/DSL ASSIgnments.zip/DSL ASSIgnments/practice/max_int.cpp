#include<iostream>
using namespace std;

int main()
{
	int i=2147483647;
	i++;
	cout<<"\n\t\t"<<i;
	
	i++;
	cout<<"\n\t\t"<<i;
return 0;
}
