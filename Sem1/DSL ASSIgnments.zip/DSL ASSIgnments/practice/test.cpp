#include<iostream>
using namespace std;

int main()
{
	cout<<"\n\tEuuuuuuuuu.........";
}
