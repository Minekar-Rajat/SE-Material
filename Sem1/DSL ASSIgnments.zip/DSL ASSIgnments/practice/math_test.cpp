#include<iostream>
using namespace std;


int main()
{
	
	cout<<"\n\t"<<(8/4/2);
}
